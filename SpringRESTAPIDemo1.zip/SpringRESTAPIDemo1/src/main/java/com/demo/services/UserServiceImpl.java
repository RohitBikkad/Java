
package com.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.demo.dto.RegisterDto;
import com.demo.entities.Role;
import com.demo.entities.User;
import com.demo.repositories.UserRepository;
import java.util.HashSet;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void registerUser(RegisterDto registerDto) throws Exception {
        validateUserData(registerDto);

        if (userRepository.existsByUsernameOrEmail(registerDto.getUsername(), registerDto.getEmail())) {
            throw new Exception("Username or email is already in use");
        }

        User user = new User();
        user.setUsername(registerDto.getUsername());
        user.setEmail(registerDto.getEmail());
        user.setPassword(passwordEncoder.encode(registerDto.getPassword()));

        
        Set<Role> roles = new HashSet<>();
        Role defaultRole = new Role();
        defaultRole.setUsername("USER");
        roles.add(defaultRole);
        user.setRoles(roles);

        userRepository.save(user);
    }

    private void validateUserData(RegisterDto registerDto) {
        
    }
}
