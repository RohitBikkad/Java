package com.demo.services;

import com.demo.dto.RegisterDto;

public interface UserService {

	void registerUser(RegisterDto registerDto) throws Exception;

    
}

